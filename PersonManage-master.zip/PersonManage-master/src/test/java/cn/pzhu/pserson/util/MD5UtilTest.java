package cn.pzhu.pserson.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class MD5UtilTest {


  @Test
  public void crypt() {
    System.out.println(MD5Util.crypt("0000"));
  }
}
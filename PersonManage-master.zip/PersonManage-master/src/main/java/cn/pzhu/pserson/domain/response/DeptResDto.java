package cn.pzhu.pserson.domain.response;

import lombok.Data;

@Data
public class DeptResDto {

  private Integer id;

  private String name;

  private String remark;

  private String num;
}
